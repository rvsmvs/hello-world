baked = [
    98, 228, 213, 115, 230, 172, 156, 189, 114, 96,
    209, 161, 71, 102, 215, 58, 104, 102, 125, 35,
    3, 174, 217, 52, 125
]

def rotr(x, k):
    return (x >> k) | ((x << (8 - k)) & 0xFF)

flag = []
for i in range(25):
    k = i % 8
    flag.append(rotr(baked[i], k))
    
print(''.join(chr(c) for c in flag))