![[Pasted image 20260105010646.png]]

@LysergicMind
rvsmvs@proton.me

`<(4Q6&}HsHb3{~M^I.[l`